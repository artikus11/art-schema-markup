=== Art Schema Markup ===
Contributors: artabr
Donate link:
Tags: woocommerce, mode catalog
Requires at least: 4.8
Tested up to: 4.9.4
Stable tag: 4.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload plugin to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Какие минимальные требования? =

WordPress 4.5
PHP 5.6


== Screenshots ==


== Changelog ==

= 2.0.1 =
* Добавлена функия обертка
* Изменен вывод разметки, теперь выводится в head

= 2.0.0 =
* Новый релиз
